#!/bin/sh
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/drive/sir/pmacct/lib  /mnt/drive/sir/pmacct/sbin/sfacctd -f /mnt/drive/sir/pmacct/conf/sfacct.conf
