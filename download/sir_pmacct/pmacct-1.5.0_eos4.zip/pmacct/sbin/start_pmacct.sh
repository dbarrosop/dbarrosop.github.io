#!/bin/sh
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/drive/spotify/sir/pmacct/lib  /mnt/drive/spotify/sir/pmacct/sbin/sfacctd -f /mnt/drive/spotify/sir/pmacct/conf/sfacct.conf
